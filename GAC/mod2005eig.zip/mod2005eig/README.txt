Michael Asher September 2012
email michael.james.asher@gmail.com

To run model.

1. Construct a BCF modflow2005 model with RCH and WEL stress packages
(others could easily be added). Place all files in wel2rch directory.

2. Remove .cbc line fram .nam file.

3. Edit folder path in runread.bat then run this.

4. run eig.py

5. Edit folder path in runhead.bat then run this.

TODO
-figure out what time units are used in simulation (t=0.0003 roughly works for stress periods of a day?)
-add other stress packages
-figure out why answers are out by a multiple of SC1 (I removed this factor from eig7.f so it works)
-test on unconfined
-find eigenvalues of Loddon problem
-etc.