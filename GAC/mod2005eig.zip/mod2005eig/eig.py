from scipy.linalg import norm, eigh, eig, tri
from numpy import fromstring
#from scipy.sparse.linalg import eigs, eigsh, spsolve, LinearOperator
from scipy.sparse import csc_matrix
from scipy import array, ones, empty, zeros
from random import random
from numpy import empty, identity ,real

########################################################## 
# Read in bas and bcf data 
########################################################## 

# read in a line containing a flattened 3way array
# assumes file is already open
def read3way(nrow,ncol,nlay,f):
   threeWay = empty((nrow,ncol,nlay))
   l = f.readline()
   l = fromstring(l,sep=' ')
   for k in xrange(nlay):
		for j in xrange(ncol):
			for i in xrange(nrow):
				irecd = i+j*nrow+k*nrow*ncol
				threeWay[i,j,k] = l[irecd]
   return threeWay 

f = open('wel2rch1/wrbasbcf.dat','r')

l = f.readline()
l = fromstring(l,dtype=int, sep=' ')
nrow = l[0]
ncol = l[1]
nlay = l[2]
print 'nrow, ncol, nlay' ,nrow,ncol,nlay

iabound = read3way(nrow,ncol,nlay,f)
allheads = read3way(nrow,ncol,nlay,f)

laycon = fromstring(f.readline(),sep=' ')
delr = fromstring(f.readline(),sep=' ')
delc = fromstring(f.readline(),sep=' ')
trpy = fromstring(f.readline(),sep=' ')
# trpy = empty((nrow,ncol))
# l = f.readline()
# l = fromstring(l,sep=' ')
# for j in xrange(ncol):
# 	for i in xrange(nrow):
# 		irecd = i+j*nrow
# 		trpy[k] = l[irecd]

alltop = read3way(nrow,ncol,nlay,f)
allbot = read3way(nrow,ncol,nlay,f)
allvct = read3way(nrow,ncol,nlay,f)
allspy = read3way(nrow,ncol,nlay,f)
allspt = read3way(nrow,ncol,nlay,f)
allcnd = read3way(nrow,ncol,nlay,f)
l = f.readline()
#numactfor = int(l)
f.close()


########################################################## 
# y = S^{-1} T x
##########################################################

def HMean(a,b):
  if(a*b==0): return 0.0
  else: return 2.0/(1.0/a + 1.0/b)
  
def Trany(x):  
  y = empty(x.shape)
  sc1 = 1.0
  
  for k in xrange(nlay):
    for j in xrange(ncol):
      for i in xrange(nrow):
        if(iabound[i,j,k]>0):
          tempT = 0.0
          sc1=allspy[i,j,k] 
#           if(laycon[k]==1):
#   	    sc1 = allspy[i,j,k]
#   	  else:
# 	    sc1 = allspt[i,j,k]
	   # sc1 = allspt[i,j,k]*delr[j]*delc[i]*delc[i]
            
          if(laycon[k]==0 or laycon[k]==2):
            tranijk=allcnd[i,j,k]
            if(i>0):
              tranim1jk=allcnd[i-1,j,k]
            else:
              tranim1jk=0.0
                    
            if(i<-1+nrow):
              tranip1jk=allcnd[i+1,j,k]
            else:
              tranip1jk=0.0
                    
            if(j>0):
              tranijm1k=allcnd[i,j-1,k]
            else:
              tranijm1k=0.0
                    
            if(j<-1+ncol):
              tranijp1k=allcnd[i,j+1,k]
            else:
              tranijp1k=0.0
                  
          else:
            tranijk=allcnd[i,j,k]*(top[i,j,k]-bot[i,j,k])
            if(i>0):
              tranim1jk=allcnd[i-1,j,k]*(top[i-1,j,k]-bot[i-1,j,k])
            else:
              tranim1jk=0.0
            
            if(i<-1+nrow):
              tranip1jk=allcnd[i+1,j,k]*(top[i+1,j,k]-bot[i+1,j,k])
            else:
              tranip1jk=0.0
            
            if(j>0):
              tranijm1k=allcnd[i,j-1,k]*(top[i,j-1,k]-bot[i,j-1,k])
            else:
              tranijm1k=0.0
            
            if(j<-1+ncol):
              tranijp1k=allcnd[i,j+1,k]*(top[i,j+1,k]-bot[i,j+1,k])
            else:
              tranijp1k=0.0
  
  #             consider row
  #
          if(i>0):
            if(iabound[i-1,j,k]>0):
              irecd = i+j*nrow+k*nrow*ncol
              tempH = HMean(tranijk,tranim1jk)
#               tempT = tempT - (1/delc[i]**2)*tempH * x[irecd] \
#                             + (1/delc[i]**2)*tempH * x[irecd-1]
              tempT = tempT - (delr[j]/delc[i])*tempH * x[irecd] \
                             + (delr[j]/delc[i])*tempH * x[irecd-1]
            
          
          if(i<-1+nrow):
            if(iabound[i+1,j,k]>0):
              irecd = i+j*nrow+k*nrow*ncol
              tempH = HMean(tranijk,tranip1jk)
#               tempT = tempT - (1/delc[i]**2)*tempH * x[irecd] \
#                             + (1/delc[i]**2)*tempH * x[irecd+1]
              tempT = tempT - (delr[j]/delc[i])*tempH * x[irecd] \
                            + (delr[j]/delc[i])*tempH * x[irecd+1]
            
          
  #
  #             consider column
  #
          if(j>0):
            if(iabound[i,j-1,k]>0):
              irecd = i+j*nrow+k*nrow*ncol
              jrecd = i+(j-1)*nrow+k*nrow*ncol
              tempH = HMean(tranijk,tranijm1k)
#               tempT = tempT - (trpy[k])*(1/delr[j]**2)*tempH * x[irecd] \
#                             + (trpy[k])*(1/delr[j]**2)*tempH * x[jrecd]
              tempT = tempT - (trpy[k])*(delc[i]/delr[j])*tempH * x[irecd] \
                            + (trpy[k])*(delc[i]/delr[j])*tempH * x[jrecd]
                            
            
          
          if(j<-1+ncol):
            if(iabound[i,j+1,k]>0):
              irecd = i+j*nrow+k*nrow*ncol
              jrecd = i+(j+1)*nrow+k*nrow*ncol
              tempH = HMean(tranijk,tranijp1k)
#               tempT = tempT - (trpy[k])*(1/delr[j]**2)*tempH * x[irecd] \
#                             + (trpy[k])*(1/delr[j]**2)*tempH * x[jrecd]
              tempT = tempT - (trpy[k])*(delc[i]/delr[j])*tempH * x[irecd] \
                             + (trpy[k])*(delc[i]/delr[j])*tempH * x[jrecd]
#              print "values", tempT, trpy[k], delc[i], delr[j], tempH, x[irecd] , (trpy[k])*(delc[i]/delr[j])*tempH * x[jrecd]
            
          
  #
  #             consider layer
  #
          if(k>0):
            if(iabound[i,j,k-1]>0):
              irecd = i+j*nrow+k*nrow*ncol
              jrecd = i+j*nrow+(k-1)*nrow*ncol
              tempT = tempT - (delc[i]*delr[j])*allvct[i,j,k] * x[irecd] \
                            + (delc[i]*delr[j])*allvct[i,j,k] * x[jrecd]
  #                  write(*,*) (delc[i]*delr[j])*allvct[i,j,k] * x[jrecd]-(delc[i]*delr[j])*allvct[i,j,k] * x[irecd]
            
          
          if(k<-1+nlay):
            if(iabound[i,j,k+1]>0):
              irecd = i+j*nrow+k*nrow*ncol
              jrecd = i+j*nrow+(k+1)*nrow*ncol
              tempT = tempT - (delc[i]*delr[j])*allvct[i,j,k+1] * x[irecd] \
                            + (delc[i]*delr[j])*allvct[i,j,k+1] * x[jrecd]
   #                 write(*,*) (delc[i]*delr[j])*allvct[i,j,k] * x[jrecd]-(delc[i]*delr[j])*allvct[i,j,k] * x[irecd]
      
  #
  #             assign y vector
  #
          irecd = i+j*nrow+k*nrow*ncol
       #   write(*,*) SC1
          y[irecd] = tempT * (1.0/sc1)
        else:
          irecd = i+j*nrow+k*nrow*ncol
          y[irecd] = 0.0
  return y
 
 
 
########################################################## 
# find eigenvalues
########################################################## 


#x1 = array([random() for x in xrange(n)])
#x1[50]=1
#print Trany(x1) 
n = nrow*ncol*nlay
A = identity(n) 
for i in xrange(n):
	A[:,i] = Trany(A[:,i])
w,v = eigh(A)

# A1 = LinearOperator((n,n),matvec=Trany) 
# w,v = eigsh(A1,k=3,which='SM', ncv = 15, return_eigenvectors=True,maxiter=10000) #,v0=initialV)

nev=n #30
fw = open("wel2rch1/valvec.dat",'w')
fw.write(str(nev)+'\n')
for i in xrange(nev):
   fw.write(str(real(w[i]))+'\n')
for i in xrange(n):
   for j in xrange(nev):
	  fw.write(str(real(v[i,j]))+'   ')
   fw.write('\n')
fw.close()

#x1= A.matvec(v[:,1])
vecTest=1
x1 = A.dot(v[:,vecTest])
print "vector"
for i in xrange(n):
	print w[vecTest]*v[i,vecTest],x1[i] 
print "values", w


# from sys import getsizeof
# print "size", getsizeof(v[1,1])
# v.transpose().tofile('fhbvec.bin',format="%23.16e")
# 
# from fortranformat import FortranRecordWriter
# line = FortranRecordWriter('E15.7')
# fw = open("fhbvec1.dat",'w')
# # fw.write(line.write(w))
# for i in xrange(nev):
# 	fw.write(str(real(w[i])))
# 	fw.write('\n')
# for i in xrange(n):
# 	#fw.write(line.write(v[i,:]))
# 	for j in xrange(nev):
# 		fw.write(str(real(v[i,j])))
# 		fw.write('\n')
# fw.close()
