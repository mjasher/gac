from mpi4py import MPI
from time import time
from scipy.linalg import norm, eigh, eig, tri
from scipy.sparse.linalg import eigs, eigsh, spsolve, LinearOperator
from scipy.sparse import csc_matrix
from scipy import array, ones, empty, zeros
from random import random
from numpy import real,empty, identity, zeros, fromstring 

########################################################## 
# Read in bas and bcf data 
########################################################## 

# read in a line containing a flattened 3way array
# assumes file is already open
def read3way(nrow,ncol,nlay,f):
   threeWay = empty((nrow,ncol,nlay))
   l = f.readline()
   l = fromstring(l,sep=' ')
   for k in xrange(nlay):
		for j in xrange(ncol):
			for i in xrange(nrow):
				irecd = i+j*nrow+k*nrow*ncol
				threeWay[i,j,k] = l[irecd]
   return threeWay 

f = open('testbasbcf.dat','r')

l = f.readline()
l = fromstring(l,dtype=int, sep=' ')
nrow = l[0]
ncol = l[1]
nlay = l[2]
print 'nrow, ncol, nlay' ,nrow,ncol,nlay

iabound = read3way(nrow,ncol,nlay,f)
allheads = read3way(nrow,ncol,nlay,f)

laycon = fromstring(f.readline(),sep=' ')
delr = fromstring(f.readline(),sep=' ')
delc = fromstring(f.readline(),sep=' ')
trpy = empty((nrow,ncol))
l = f.readline()
l = fromstring(l,sep=' ')
for j in xrange(ncol):
	for i in xrange(nrow):
		irecd = i+j*nrow
		trpy[i,j] = l[irecd]

top = read3way(nrow,ncol,nlay,f)
bot = read3way(nrow,ncol,nlay,f)
allvct = read3way(nrow,ncol,nlay,f)
allspy = read3way(nrow,ncol,nlay,f)
allspt = read3way(nrow,ncol,nlay,f)
allcnd = read3way(nrow,ncol,nlay,f)
l = f.readline()
numactfor = int(l)
f.close()

n = nrow*ncol*nlay
m = numactfor

########################################################## 
# MPI
##########################################################

comm = MPI.COMM_WORLD
mpirank = comm.Get_rank()
mpisize = comm.Get_size()
print "WARNING: np must divide the number of active cells"

########################################################## 
# find active cells
##########################################################
actdict = empty((nrow*ncol*nlay))
revdict = empty((m,3), dtype='int')
actcounter = 0 
for k in xrange(nlay):
  for j in xrange(ncol):
    for i in xrange(nrow):
      if(iabound[i,j,k]>0):
      	actdict[i+j*nrow+k*nrow*ncol] = actcounter
	revdict[actcounter,:] = i,j,k
	actcounter = actcounter + 1
      else: 
        actdict[i+j*nrow+k*nrow*ncol] = -1
	 
print 'Active cells', actcounter
if (actcounter != numactfor): print "ACTIVE CELL MISCOUNT"
########################################################## 
# y = S^{-1} T x
##########################################################

def HMean(a,b):
  if(a*b==0): return 0.0
  else: return 2.0/(1.0/a + 1.0/b)
  
def unflat(flatN):
  return [(flatN % (nrow*ncol)) % nrow, (flatN % (nrow*ncol)) / nrow, flatN/(nrow*ncol)]

def Trany(x):  
  yg = empty(x.shape,dtype='d')
  y = empty((numactfor/mpisize),dtype='d')
  sc1 = 1.0
  
    
#  sblock = unflat( (mpirank)*(x.shape[0]/mpisize) ) 
#  if ( mpirank == 0 ):
#    eblock = unflat( (mpirank+1)*(x.shape[0]/mpisize) ) 
#  else: 
#    eblock = unflat( x.shape[0] ) 
#

  for flatN in xrange(numactfor/mpisize):

 # for k in range(sblock[2],eblock[2]):
 #   for j in range(sblock[1],eblock[1]):
 #     for i in range(sblock[0],eblock[0]):
        i,j,k = revdict[mpirank*(numactfor/mpisize)+flatN,:]
        if(iabound[i,j,k]>0):
          tempT = 0.0
          
	  if(laycon[k]==1):
  	    sc1 = allspy[i,j,k]
  	  else:
	    sc1 = allspt[i,j,k]
	   # sc1 = allspt[i,j,k]*delr[j]*delc[i]*delc[i]
            
          if(laycon[k]==0 or laycon[k]==2):
            tranijk=allcnd[i,j,k]
            if(i>0):
              tranim1jk=allcnd[i-1,j,k]
            else:
              tranim1jk=0.0
                    
            if(i<-1+nrow):
              tranip1jk=allcnd[i+1,j,k]
            else:
              tranip1jk=0.0
                    
            if(j>0):
              tranijm1k=allcnd[i,j-1,k]
            else:
              tranijm1k=0.0
                    
            if(j<-1+ncol):
              tranijp1k=allcnd[i,j+1,k]
            else:
              tranijp1k=0.0
                  
          else:
            tranijk=allcnd[i,j,k]*(top[i,j,k]-bot[i,j,k])
            if(i>0):
              tranim1jk=allcnd[i-1,j,k]*(top[i-1,j,k]-bot[i-1,j,k])
            else:
              tranim1jk=0.0
            
            if(i<-1+nrow):
              tranip1jk=allcnd[i+1,j,k]*(top[i+1,j,k]-bot[i+1,j,k])
            else:
              tranip1jk=0.0
            
            if(j>0):
              tranijm1k=allcnd[i,j-1,k]*(top[i,j-1,k]-bot[i,j-1,k])
            else:
              tranijm1k=0.0
            
            if(j<-1+ncol):
              tranijp1k=allcnd[i,j+1,k]*(top[i,j+1,k]-bot[i,j+1,k])
            else:
              tranijp1k=0.0
  
  #             consider row
  #
          if(i>0):
            if(iabound[i-1,j,k]>0):
              irecd = i+j*nrow+k*nrow*ncol
	      jrecd = i-1+j*nrow+k*nrow*ncol
              tempH = HMean(tranijk,tranim1jk)
#               tempT = tempT - (1/delc[i]**2)*tempH * x[actdict[irecd]] \
#                             + (1/delc[i]**2)*tempH * x[irecd-1]
              tempT = tempT - (delr[j]/delc[i])*tempH * x[actdict[irecd]] \
                             + (delr[j]/delc[i])*tempH * x[actdict[jrecd]]
            
          
          if(i<-1+nrow):
            if(iabound[i+1,j,k]>0):
              irecd = i+j*nrow+k*nrow*ncol
	      jrecd = i+1+j*nrow+k*nrow*ncol
              tempH = HMean(tranijk,tranip1jk)
#               tempT = tempT - (1/delc[i]**2)*tempH * x[actdict[irecd]] \
#                             + (1/delc[i]**2)*tempH * x[irecd+1]
              tempT = tempT - (delr[j]/delc[i])*tempH * x[actdict[irecd]] \
                            + (delr[j]/delc[i])*tempH * x[actdict[jrecd]]
            
          
  #
  #             consider column
  #
          if(j>0):
            if(iabound[i,j-1,k]>0):
              irecd = i+j*nrow+k*nrow*ncol
              jrecd = i+(j-1)*nrow+k*nrow*ncol
              tempH = HMean(tranijk,tranijm1k)
#               tempT = tempT - (trpy[i,j])*(1/delr[j]**2)*tempH * x[actdict[irecd]] \
#                             + (trpy[i,j])*(1/delr[j]**2)*tempH * x[actdict[jrecd]]
              tempT = tempT - (trpy[i,j])*(delc[i]/delr[j])*tempH * x[actdict[irecd]] \
                            + (trpy[i,j])*(delc[i]/delr[j])*tempH * x[actdict[jrecd]]
                            
            
          
          if(j<-1+ncol):
            if(iabound[i,j+1,k]>0):
              irecd = i+j*nrow+k*nrow*ncol
              jrecd = i+(j+1)*nrow+k*nrow*ncol
              tempH = HMean(tranijk,tranijp1k)
#               tempT = tempT - (trpy[i,j])*(1/delr[j]**2)*tempH * x[actdict[irecd]] \
#                             + (trpy[i,j])*(1/delr[j]**2)*tempH * x[actdict[jrecd]]
              tempT = tempT - (trpy[i,j])*(delc[i]/delr[j])*tempH * x[actdict[irecd]] \
                             + (trpy[i,j])*(delc[i]/delr[j])*tempH * x[actdict[jrecd]]
#              print "values", tempT, trpy[i,j], delc[i], delr[j], tempH, x[actdict[irecd]] , (trpy[i,j])*(delc[i]/delr[j])*tempH * x[actdict[jrecd]]
            
          
  #
  #             consider layer
  #
          if(k>0):
            if(iabound[i,j,k-1]>0):
              irecd = i+j*nrow+k*nrow*ncol
              jrecd = i+j*nrow+(k-1)*nrow*ncol
              tempT = tempT - (delc[i]*delr[j])*allvct[i,j,k] * x[actdict[irecd]] \
                            + (delc[i]*delr[j])*allvct[i,j,k] * x[actdict[jrecd]]
            
          
          if(k<-1+nlay):
            if(iabound[i,j,k+1]>0):
              irecd = i+j*nrow+k*nrow*ncol
              jrecd = i+j*nrow+(k+1)*nrow*ncol
              tempT = tempT - (delc[i]*delr[j])*allvct[i,j,k+1] * x[actdict[irecd]] \
                            + (delc[i]*delr[j])*allvct[i,j,k+1] * x[actdict[jrecd]]
      
  #
  #             assign y vector
          y[flatN] = tempT *(1.0/sc1)
#
#          irecd = i+j*nrow+k*nrow*ncol
#          y[actdict[irecd]] = tempT * (1.0/sc1)
#        else:
#          irecd = i+j*nrow+k*nrow*ncol
#          y[actdict[irecd]] = 0.0

  comm.Allgather([y,  MPI.DOUBLE], [yg, MPI.DOUBLE])
  return yg
 
 
 
########################################################## 
# find eigenvalues
########################################################## 

A1 = LinearOperator((m,m),matvec=Trany,dtype='d') 
# A = A1.matmat(A)  
nev =10 
testEig = 1 
w,v = eigs(A1,k=nev,which='SM', ncv = 20, return_eigenvectors=True,maxiter=100000) #,v0=initialV)


x= A1.matvec(v[:,testEig])

#A = identity(m) 
#for i in xrange(m):
#  A[:,i] = Trany(A[:,i])

if(mpirank==0):
 
  fw = open("fhbvec.dat",'w')
  fw.write(str(nev)+'\n')
  for i in xrange(nev):
    fw.write(str(real(w[i]))+'\n')
  for i in xrange(m):
    for j in xrange(nev):
      fw.write(str(real(v[i,j]))+'   ')
    fw.write('\n')
  fw.close()

  print "vector"
  for i in xrange(m):
	print w[testEig]*v[i,testEig],x[i] 
  print "values", w
  
  
#  w1,v1 = eig(A)
#  x1 = A.dot(v1[:,testEig])
#  print "values", w1
#
#  print "vector"
#  for i in xrange(n):
#	print w1[testEig]*v1[i,testEig],x1[i] 
# 
#  actcounter = 0
#  vecy = zeros((n))
#  for k in xrange(nlay):
#    for j in xrange(ncol):
#      for i in xrange(nrow):
#        if(iabound[i,j,k]>0):	
#          vecy[i+j*nrow+k*nrow*ncol] = v[actcounter,1]
#	  actcounter = actcounter + 1
#  print "vecy", vecy
#
