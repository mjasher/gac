rm -f bcf2ss.lst bcf2ss.sh check.out ibs.lst ibs.sh str.lst str.sh
rm -f tlkp1.lst tlkp1.drw tlkp1.flw tlkp1.sh twri.lst twri.sh
rm -f restest.lst restest.sh
